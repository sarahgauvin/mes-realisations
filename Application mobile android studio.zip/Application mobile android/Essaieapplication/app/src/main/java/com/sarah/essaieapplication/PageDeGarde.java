package com.sarah.essaieapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class PageDeGarde extends AppCompatActivity {

    Button boutonDemarrer ;
    ImageView photoDeFusee ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_de_garde);
        photoDeFusee = (ImageView) findViewById(R.id.photoDeFusee) ;
        boutonDemarrer = (Button) findViewById(R.id.BoutonDemarrer);
        boutonDemarrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pageDeGarde = new Intent(PageDeGarde.this, formulaire.class);
                startActivity(pageDeGarde);
            }
        });
    }
}
