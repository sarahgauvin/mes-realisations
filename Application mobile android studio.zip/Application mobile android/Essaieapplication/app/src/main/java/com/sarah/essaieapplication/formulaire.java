package com.sarah.essaieapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;

public class formulaire extends AppCompatActivity {

    Button btnPrendrePhoto ;
    ImageView img, img2, img3, img4, img5 ;
    int compteurDeClick=0 ;
    boolean compt1 = false, compt2 = false, compt3 = false, compt4= false, compt5= false ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulaire);
//Récupération des éléments :
        img=(ImageView)  findViewById(R.id.imgAfficherPhoto1);
        img2=(ImageView)  findViewById(R.id.imgAfficherPhoto2);
        img3=(ImageView)  findViewById(R.id.imgAfficherPhoto3);
        img4=(ImageView)  findViewById(R.id.imgAfficherPhoto4);
        img5=(ImageView)  findViewById(R.id.imgAfficherPhoto5);
        btnPrendrePhoto = (Button) findViewById(R.id.btnPrendrePhoto);

//supprimer les photos :
        img.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                        img.setImageBitmap(null);
                        compt1 = false ;
                return false;
            }
        });
        img2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                img2.setImageBitmap(null);
                compt2 = false ;
                return false;
            }
        });
        img3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                img3.setImageBitmap(null);
                compt3 = false ;
                return false;
            }
        });
        img4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                img4.setImageBitmap(null);
                compt4 = false ;
                return false;
            }
        });
        img5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                img5.setImageBitmap(null);
                compt5 = false ;
                return false;
            }
        });

//Prendre des photos :
        btnPrendrePhoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                Intent intent =new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }
        } );

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        compteurDeClick = compteurDeClick + 1 ;

        if(!compt1)
        {
            Bitmap bit= (Bitmap) data.getExtras().get("data");
            img.setImageBitmap(bit);
            compt1 = true ;
        }
        else
        {
            if (!compt2)
            {
                Bitmap bit2= (Bitmap) data.getExtras().get("data");
                img2.setImageBitmap(bit2);
                compt2 = true;
            }
            else
            {
                if (!compt3)
                {
                    Bitmap bit3= (Bitmap) data.getExtras().get("data");
                    img3.setImageBitmap(bit3);
                    compt3 = true;
                }
                else
                {
                    if (!compt4)
                    {
                        Bitmap bit4= (Bitmap) data.getExtras().get("data");
                        img4.setImageBitmap(bit4);
                        compt4 = true;
                    }
                    else
                    {
                        if (!compt5)
                        {
                            Bitmap bit5= (Bitmap) data.getExtras().get("data");
                            img5.setImageBitmap(bit5);
                            compt5 = true;
                        }
                    }
                }
            }
        }

        /**
        if(compteurDeClick ==2) {

            Bitmap bit2= (Bitmap) data.getExtras().get("data");
            img2.setImageBitmap(bit2);

       }
        if(compteurDeClick ==3) {

            Bitmap bit3= (Bitmap) data.getExtras().get("data");
            img3.setImageBitmap(bit3);

        }
        if(compteurDeClick ==4) {

            Bitmap bit4= (Bitmap) data.getExtras().get("data");
            img4.setImageBitmap(bit4);
        }
        if(compteurDeClick ==5) {

            Bitmap bit5= (Bitmap) data.getExtras().get("data");
            img5.setImageBitmap(bit5);

        }
         **/

    }
}
